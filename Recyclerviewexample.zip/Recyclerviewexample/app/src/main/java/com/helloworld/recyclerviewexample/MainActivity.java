package com.helloworld.recyclerviewexample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
ArrayList<contactModel> arrContacts =new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerContact);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        arrContacts.add(new contactModel(R.drawable.a, "A","9876543210"));
        arrContacts.add(new contactModel(R.drawable.a, "B","9876545454"));
        arrContacts.add(new contactModel(R.drawable.a, "C","9876544545"));
        arrContacts.add(new contactModel(R.drawable.a, "D","9876543246"));
        arrContacts.add(new contactModel(R.drawable.a, "E","9876543247"));
        arrContacts.add(new contactModel(R.drawable.a, "F","9876543248"));
        arrContacts.add(new contactModel(R.drawable.a, "G","9876543249"));
        arrContacts.add(new contactModel(R.drawable.a, "H","9876543250"));
        arrContacts.add(new contactModel(R.drawable.a, "I","9876543251"));

        RecycleContactAdapter adapter = new RecycleContactAdapter(this,arrContacts);
        recyclerView.setAdapter(adapter);

    }
}